// PulsePage asset and authored scene contract. Animated MeshBuilder was chosen explicitly by the user.
export const PULSEPAGE_ASSETS = {
 backend:"MeshBuilder (animated parametric notation)",
 material:"SimpleVertexBaseColor.lspkg/vertexBaseColorMaterial.mat",
 scripts:["PulsePageApp.ts","PulsePageControlsView.ts","PulsePageNotation.ts","PulsePageTransport.ts"],
 roots:["PulsePage Music Stand","PulsePage Controls","PulsePage Notation"],
 phrase:"Original C-major treble phrase: C4 E4 G4 A4 | G4(half) F4 E4 | D4(eighth) E4(eighth) F4 G4 B4 | A4 G4 C4(half)",
 audio:[],icons:[]
}
