// Run with: node --experimental-strip-types Assets/Tests/PulsePageState.test.mjs
import {stripTypeScriptTypes} from "node:module";
import fs from "node:fs";
const path=new URL("../Scripts/PulsePageTransport.ts",import.meta.url);
const src=stripTypeScriptTypes(fs.readFileSync(path,"utf8"));
const {PulsePageTransport:S,PHRASE:P}=await import("data:text/javascript;base64,"+Buffer.from(src).toString("base64"));
let n=0;const ok=(x,m)=>{if(!x)throw Error(m);n++};
const near=(a,b)=>Math.abs(a-b)<1e-8;
ok(P.reduce((a,b)=>a+b.duration,0)===16,"phrase duration");
for(let bar=0;bar<4;bar++)ok(P.filter(x=>Math.floor(x.start/4)===bar).reduce((a,b)=>a+b.duration,0)===4,"bar duration");
for(let i=1;i<P.length;i++)ok(P[i].start===P[i-1].start+P[i-1].duration,"contiguous phrase");
let s=new S();ok(s.bpm===80&&s.phase==="ready","initial");
s.toggle();s.advance(2.25);ok(s.phase==="count-in"&&s.snapshot().count===4,"count in");
s.advance(.75);ok(s.phase==="playing"&&near(s.position,0),"four count-in beats");
s.advance(.375);const held=s.position;s.toggle();s.advance(12);ok(near(s.position,held),"pause freeze");
s.toggle();s.advance(.375);ok(near(s.position,1),"resume exact beat");
s.restart();ok(s.phase==="ready"&&s.position===-4,"restart paused");
s.cycleTempo();ok(s.bpm===100,"80 to100");s.cycleTempo();ok(s.bpm===60,"100 to60");
s.toggle();s.advance(1);ok(s.position===-3,"60bpm");s.cycleTempo();ok(s.bpm===60,"active tempo guard");
s.toggle();s.cycleTempo();ok(s.bpm===80,"paused tempo change");s.toggle();s.advance(100);
ok(s.phase==="finished"&&s.position===16,"finish clamps");s.advance(100);s.toggle();ok(s.position===16&&s.phase==="finished","finish stable");
for(let k=0;k<100;k++){s.restart();s.toggle();s.advance(.75);ok(s.position===-3,"restart no accumulation")}
const a=new S(),b=new S();a.bpm=60;b.bpm=100;a.toggle();b.toggle();a.advance(6);b.advance(6);ok(b.position>a.position,"100 faster than60");
const q=new S();q.toggle();for(let i=0;i<900;i++)q.advance(1/60);ok(q.position===16&&q.phase==="finished","frame integration finish boundary");
for(const bpm of [60,80,100]){const t=new S();t.bpm=bpm;t.toggle();t.advance(4*60/bpm);ok(t.phase==="playing"&&t.position===0,"count-in boundary");for(const note of P){ok(t.snapshot().note===P.indexOf(note),"note boundary "+note.start);t.advance(note.duration*60/bpm)}ok(t.phase==="finished","finish "+bpm)}
const c=new S();c.toggle();c.advance(.2);c.toggle();const p=c.position;c.advance(10);ok(c.position===p,"pause during count-in");c.toggle();c.advance(.1);ok(near(c.position,p+.1*80/60),"resume count-in");
console.log(JSON.stringify({passed:n,failed:0}));
